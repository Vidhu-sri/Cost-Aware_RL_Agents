"""Derive a readable pilot report and command evidence from saved traces."""

import json
from pathlib import Path
import sys

from adk_eval_core.tracing import SessionTrace


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def main(batch):
    summary = json.loads((batch / "summary.json").read_text())
    lines = ["# SWE-bench train trajectory pilot", "",
             "Task: `gitpython-developers__GitPython-1028` at base commit "
             "`9b7839e6b55953ddac7e8f13b2f9e2fa2dea528b`.", "",
             "Both attempts used the pinned training issue and a clean checkout. "
             "Gold patches, test patches and evaluator metadata were excluded from agent input.", "",
             "| Attempt | Seed | Agent time | Tools | Model responses with usage | Patch | Agent timeout | Grading |",
             "|---|---:|---:|---:|---:|---:|---|---|" ]
    sections = []
    for item in summary["attempts"]:
        number = item["attempt"]
        run = Path(item["run_dir"])
        trace = SessionTrace.from_json(run / "trace.json")
        outcome = item["outcome"]
        settings = json.loads((run / "effective_settings.json").read_text())
        evidence = []
        pending = None
        submitted = None
        for entry in trace.entries:
            if entry.event_type == "tool_call" and entry.tool_name == "run_command":
                pending = {"command": entry.tool_args.get("command") if entry.tool_args else None,
                           "elapsed_seconds": round(entry.elapsed, 3)}
            elif entry.event_type == "tool_response" and entry.tool_name == "run_command":
                response = json.loads(entry.tool_result)
                evidence.append({**(pending or {}), "status": response.get("status"),
                                 "stdout": response.get("stdout"), "stderr": response.get("stderr"),
                                 "exit_code": response.get("exit_code"),
                                 "error_type": response.get("error_type"),
                                 "error_message": response.get("error_message")})
                pending = None
            elif entry.event_type == "tool_call" and entry.tool_name == "submit_patch":
                submitted = round(entry.elapsed, 3)
        write_json(run / "command_evidence.json", evidence)
        test_commands = [e for e in evidence if any((e["command"] or "").startswith(token)
                         for token in ("pytest ", "python3 -m pytest", "python3 -m unittest",
                                       "python3 check_packages.py", "python3 setup.py install"))]
        write_json(run / "test_evidence.json", {
            "official_grading": "ungraded", "resolved": None,
            "test_or_ad_hoc_check_commands": test_commands,
            "other_commands": [e for e in evidence if e not in test_commands],
        })
        outcome["patch_submission_seconds"] = submitted
        outcome["agent_elapsed_seconds"] = round(trace.duration, 3)
        outcome["sampling_seed"] = settings["local_pilot"]["sampling_seed"]
        outcome["test_or_ad_hoc_check_count"] = len(test_commands)
        outcome["test_evidence_path"] = str(run / "test_evidence.json")
        write_json(run / "outcome.enriched.json", outcome)
        lines.append(f"| {number} | {outcome['sampling_seed']} | {trace.duration:.1f}s | "
                     f"{outcome['tool_calls']} | {outcome['llm_responses_with_usage']} | "
                     f"{outcome['patch_bytes']} bytes | {outcome['agent_timed_out']} | ungraded |")
        sections.extend(["", f"## Attempt {number}", "",
                      f"Patch submission: {submitted}s after agent start.",
                      f"Agent error: {outcome['agent_error']!r}. "
                      f"Outer timeout: {json.loads((run / 'monitor.json').read_text())['outer_timed_out']}.",
                      f"Token usage: {outcome['token_usage']['total_tokens']} total "
                      f"({outcome['token_usage']['total_prompt_tokens']} prompt, "
                      f"{outcome['token_usage']['total_completion_tokens']} completion).",
                      f"Patch: [`attempt-{number}/agent.patch`](attempt-{number}/agent.patch). "
                      f"Full trace: [`attempt-{number}/trace.json`](attempt-{number}/trace.json). "
                      f"Readable rollout: [`attempt-{number}/rollout.md`](attempt-{number}/rollout.md).",
                      "", "Observed test or ad hoc check commands:", ""])
        if test_commands:
            for command in test_commands:
                sections.append(f"- `{command['command']}`: status `{command['status']}`, "
                             f"exit code `{command['exit_code']}`. "
                             "See `test_evidence.json` for full output.")
        else:
            sections.append("- None recorded.")
        sections.append("")
    lines.extend(sections)
    lines.extend(["## Interpretation", "",
                  "Both runs produced model-generated patches. The pinned train row has no "
                  "reliable FAIL_TO_PASS labels or validated evaluator setup; therefore "
                  "`grading_status` is `ungraded` and `resolved` is `null` for both. "
                  "Agent-run checks are evidence only and do not establish resolution.", "",
                  "Attempt 1's `unittest` command failed with four errors because the "
                  "source-only checkout lacks the historical `0.1.6` Git ref used by its test fixtures. "
                  "The harness represented this as a `CommandError`, so the exact numeric exit code "
                  "was not present in the trace. Attempt 2's `check_packages.py` was an ad hoc "
                  "package-discovery check and exited 0; it was not official grading.", "",
                  f"Owned server cleanup: `{summary['server_cleanup']}`.", ""])
    (batch / "combined_rollout_summary.md").write_text("\n".join(lines))


if __name__ == "__main__":
    main(Path(sys.argv[1]).resolve())
