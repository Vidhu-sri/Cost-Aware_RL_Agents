"""Pinned SWE-bench training loaders with an explicit agent-input boundary.

This module never downloads data. Evaluation datasets are represented by ID
manifests only; their gold patches are not available through these loaders.
"""

import hashlib
import json
from pathlib import Path

import pyarrow.parquet as pq


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "data_manifest.v1.json"
SAFE_FIELDS = ("instance_id", "repo", "base_commit", "problem_statement")


def manifest():
    data = json.loads(MANIFEST.read_text())
    if data.get("schema_version") != 1:
        raise ValueError("Unsupported SWE-bench data manifest")
    return data


def task_ids(dataset_id, split):
    """Return pinned IDs only; never load evaluation patch or test fields."""
    record = manifest()["datasets"][dataset_id]["splits"][split]
    path = ROOT / record["task_ids_path"]
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != record["task_ids_sha256"]:
        raise ValueError(f"Task ID manifest changed: {dataset_id}/{split}")
    ids = raw.decode().splitlines()
    if len(ids) != record["rows"] or len(ids) != len(set(ids)):
        raise ValueError(f"Task ID count changed: {dataset_id}/{split}")
    return ids


def _training_file():
    data = manifest()
    source = data["training_source"]
    record = data["datasets"][source["dataset_id"]]["splits"][source["split"]]
    path = ROOT / record["retained_parquet_path"]
    if not path.is_file():
        raise FileNotFoundError(f"Pinned training source missing: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest() != record["parquet_sha256"]:
        raise ValueError("Pinned training Parquet checksum differs from manifest")
    return path, record


def iter_agent_inputs(batch_size=256):
    """Yield train-split prompts; gold and test patches are never read."""
    path, record = _training_file()
    parquet = pq.ParquetFile(path)
    if parquet.metadata.num_rows != record["rows"]:
        raise ValueError("Training row count differs from manifest")
    for batch in parquet.iter_batches(columns=list(SAFE_FIELDS), batch_size=batch_size):
        for row in batch.to_pylist():
            yield row


def iter_sft_examples(batch_size=256):
    """Yield train-split prompt and gold-patch target for supervised learning.

    The target is separate from the prompt; never pass target_patch to an agent.
    """
    path, record = _training_file()
    parquet = pq.ParquetFile(path)
    if parquet.metadata.num_rows != record["rows"]:
        raise ValueError("Training row count differs from manifest")
    for batch in parquet.iter_batches(columns=[*SAFE_FIELDS, "patch"], batch_size=batch_size):
        for row in batch.to_pylist():
            yield {"prompt": {field: row[field] for field in SAFE_FIELDS},
                   "target_patch": row["patch"]}
