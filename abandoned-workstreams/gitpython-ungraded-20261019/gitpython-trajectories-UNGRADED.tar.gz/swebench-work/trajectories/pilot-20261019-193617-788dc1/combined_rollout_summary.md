# SWE-bench train trajectory pilot

Task: `gitpython-developers__GitPython-1028` at base commit `9b7839e6b55953ddac7e8f13b2f9e2fa2dea528b`.

Both attempts used the pinned training issue and a clean checkout. Gold patches, test patches and evaluator metadata were excluded from agent input.

| Attempt | Seed | Agent time | Tools | Model responses with usage | Patch | Agent timeout | Grading |
|---|---:|---:|---:|---:|---:|---|---|
| 1 | 1028 | 85.4s | 8 | 9 | 615 bytes | False | ungraded |
| 2 | 21028 | 135.3s | 12 | 13 | 602 bytes | False | ungraded |

## Attempt 1

Patch submission: 77.569s after agent start.
Agent error: None. Outer timeout: False.
Token usage: 59702 total (57587 prompt, 2115 completion).
Patch: [`attempt-1/agent.patch`](attempt-1/agent.patch). Full trace: [`attempt-1/trace.json`](attempt-1/trace.json). Readable rollout: [`attempt-1/rollout.md`](attempt-1/rollout.md).

Observed test or ad hoc check commands:

- `python3 -m unittest git/test/test_base.py`: status `error`, exit code `None`. See `test_evidence.json` for full output.


## Attempt 2

Patch submission: 126.909s after agent start.
Agent error: None. Outer timeout: False.
Token usage: 95475 total (91902 prompt, 3573 completion).
Patch: [`attempt-2/agent.patch`](attempt-2/agent.patch). Full trace: [`attempt-2/trace.json`](attempt-2/trace.json). Readable rollout: [`attempt-2/rollout.md`](attempt-2/rollout.md).

Observed test or ad hoc check commands:

- `python3 check_packages.py`: status `ok`, exit code `0`. See `test_evidence.json` for full output.

## Interpretation

Both runs produced model-generated patches. The pinned train row has no reliable FAIL_TO_PASS labels or validated evaluator setup; therefore `grading_status` is `ungraded` and `resolved` is `null` for both. Agent-run checks are evidence only and do not establish resolution.

Attempt 1's `unittest` command failed with four errors because the source-only checkout lacks the historical `0.1.6` Git ref used by its test fixtures. The harness represented this as a `CommandError`, so the exact numeric exit code was not present in the trace. Attempt 2's `check_packages.py` was an ad hoc package-discovery check and exited 0; it was not official grading.

Owned server cleanup: `{'pid': 1095115, 'process_exited': True, 'port_8001_closed': True}`.
