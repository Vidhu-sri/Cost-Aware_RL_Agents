"""Write a safe, unstarted one-task trajectory smoke plan."""

import json
import os
from pathlib import Path

import psutil

from loaders import iter_agent_inputs, manifest


ROOT = Path(__file__).resolve().parent
TASK_ID = "gitpython-developers__GitPython-1028"
OUT = ROOT / "trajectories/smoke"


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def main():
    task = next(row for row in iter_agent_inputs() if row["instance_id"] == TASK_ID)
    if set(task) != {"instance_id", "repo", "base_commit", "problem_statement"}:
        raise ValueError("Agent input includes an unapproved field")
    source = manifest()["training_source"]
    disk = os.statvfs(ROOT)
    OUT.mkdir(parents=True, exist_ok=True)
    write_json(OUT / "agent_input.json", task)
    write_json(OUT / "attempt_plan.v1.json", {
        "schema_version": 1,
        "status": "blocked_preflight; no attempts started",
        "source": source,
        "task_id": TASK_ID,
        "agent_input_path": "agent_input.json",
        "concurrency": 1,
        "attempts": [
            {"label": "gitpython-1028-attempt-01", "status": "not_started", "sampling_settings": None,
             "trace_path": None, "patch_path": None, "test_output_path": None},
            {"label": "gitpython-1028-attempt-02", "status": "not_started", "sampling_settings": None,
             "trace_path": None, "patch_path": None, "test_output_path": None},
        ],
        "required_before_run": [
            "Provision one pinned base-commit repository snapshot without significant disk use",
            "Provision one task image and evaluation script with known test dependencies",
            "Validate a SWE-bench-specific container monitor and owned-container cleanup",
            "Keep gold patch and test patch outside the agent-visible input and filesystem",
            "Verify model request sampling and independent attempt state before assigning seeds",
        ],
    })
    write_json(OUT / "preflight.v1.json", {
        "task_id": TASK_ID,
        "status": "stopped_before_generation",
        "disk_free_bytes_at_plan": disk.f_bavail * disk.f_frsize,
        "host_available_ram_bytes_at_plan": psutil.virtual_memory().available,
        "gpu_free_mib_observed": 79615,
        "other_user_gpu_pid_observed": 3094787,
        "other_user_gpu_memory_mib_observed": 1422,
        "local_swebench_task_image": False,
        "local_images": ["gemma-fastapi-sandbox", "gemma-rich-sandbox", "gemma-httpx-sandbox",
                         "gemma-requests-sandbox", "python:3.13-slim", "hello-world"],
        "training_row_missing_official_runner_fields": ["image", "eval_script", "log_parser", "eval_type"],
        "training_split_rows_with_nonempty_FAIL_TO_PASS": 0,
        "swebench_specific_monitoring_and_cleanup_validated": False,
        "attempts_started": 0,
        "reason": "No ready task image or official test specification; existing Gemma monitor is not validated for this SWE-bench path.",
    })


if __name__ == "__main__":
    main()
