# Isolated SWE-bench workstream

This directory is separate from `data/`, `baseline-kit/results/`, and training
directories used for the Gemma Developer Agent competition. No SWE-bench
evaluation, model serving, image build, or training job has run here.

The official source repository is in `SWE-bench/`. Its exact commit and the
dataset revisions, split counts, columns, file hashes, and task-ID manifests
are pinned in `data_manifest.v1.json`. `metadata/hub_catalog.json` is the
Hugging Face metadata snapshot; `metadata/dataset_scan.json` records checks
made directly against pinned Parquet files. The ID lists are under
`metadata/task_ids/`. Evaluation Parquet payloads were temporary inspection
files and are not retained.

The only retained dataset rows are the official Princeton NLP `train` split
under `training-source/raw/`. It has 19,008 issue/fix pairs and no exact
`instance_id` overlap with the inspected dev/test splits. This ID check does
not establish semantic or repository-level non-overlap.

`loaders.py` exposes `iter_agent_inputs()`, which reads only `instance_id`,
`repo`, `base_commit`, and `problem_statement`. Gold `patch`, `test_patch`, and
test labels never enter that agent-input iterator. `iter_sft_examples()`
returns the same prompt plus the gold patch in a separate `target_patch`
field for possible supervised training. Do not pass that target to an agent.
`task_ids(dataset_id, split)` returns ID metadata only for evaluation splits.

Gold fixes support supervised examples. DPO would require genuine
chosen/rejected responses for the same prompt. GRPO would require multiple
generated rollouts per task and test-based rewards. Neither preference pairs
nor rollout groups have been created here.

The next step before any training is to choose a concrete SFT recipe, review
data licensing and contamination criteria beyond exact IDs, and build the
necessary repository snapshots in this isolated workstream. Evaluation data
must remain excluded from training and from agent-visible inputs.
