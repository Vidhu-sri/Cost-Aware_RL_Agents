"""Two bounded, ungraded Gemma trajectories on one pinned SWE-bench train row.

The agent receives only the safe loader fields and an archive of the base tree.
The parent owns the vLLM process group and each run's labeled Docker containers.
"""

import argparse
import asyncio
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.request
import uuid

import docker
import psutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
KIT = ROOT / "baseline-kit"
sys.path.insert(0, str(KIT))
sys.path.insert(0, str(HERE))
from loaders import iter_agent_inputs  # noqa: E402
from run_docker_agent_all import gpu_free_mib, stop_server  # noqa: E402

TASK_ID = "gitpython-developers__GitPython-1028"
IMAGE = "swebench-gitpython-smoke:base-9b7839e6"
SNAPSHOT = HERE / "snapshots/gitpython-1028-base.tar.gz"
WHEELS = HERE / "docker/gitpython-1028/wheels"
MODEL_URL = "http://127.0.0.1:8001/v1"
MODEL_ALIAS = "gemma-4-31b-it-qat-w4a16-ct"
LABEL = "swebench.local.trajectory.run"

for key, value in {
    "LITELLM_LOCAL_MODEL_COST_MAP": "True", "OTEL_SDK_DISABLED": "true",
    "LITELLM_TELEMETRY": "False", "HF_HUB_OFFLINE": "1",
    "TRANSFORMERS_OFFLINE": "1",
}.items():
    os.environ[key] = value


def write_json(path, value):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, default=str) + "\n")
    tmp.replace(path)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def task_input():
    task = next(row for row in iter_agent_inputs() if row["instance_id"] == TASK_ID)
    assert set(task) == {"instance_id", "repo", "base_commit", "problem_statement"}
    assert task["base_commit"] == "9b7839e6b55953ddac7e8f13b2f9e2fa2dea528b"
    return task


def owned(client, run_id):
    return client.containers.list(all=True, filters={"label": f"{LABEL}={run_id}"})


def cleanup(client, run_id):
    removed = []
    for container in owned(client, run_id):
        cid = container.id
        try:
            container.stop(timeout=2)
        except docker.errors.DockerException:
            pass
        try:
            container.remove(force=True)
        except docker.errors.NotFound:
            pass
        removed.append(cid)
    return removed


def container_rss(container):
    container.reload()
    pid = container.attrs.get("State", {}).get("Pid", 0)
    if not pid:
        return {"host_pid": pid, "processes": 0, "rss_bytes": 0}
    try:
        namespace = os.readlink(f"/proc/{pid}/ns/pid")
        members = []
        for proc in psutil.process_iter(["pid"]):
            try:
                if os.readlink(f"/proc/{proc.pid}/ns/pid") == namespace:
                    members.append(proc)
            except (psutil.Error, OSError):
                continue
        return {"host_pid": pid, "processes": len(members),
                "rss_bytes": sum(proc.memory_info().rss for proc in members)}
    except (psutil.Error, OSError):
        return {"host_pid": pid, "processes": None, "rss_bytes": None}


def worker(run_dir, run_id, seed, diagnostic=False):
    import shlex
    from swegemma.sandbox.docker import ContainerManager, ContainerConfig
    from swegemma.harness import agent_runner
    from swegemma.harness.container_setup import extract_snapshot
    from swegemma.models.task import Task
    from swegemma.config import EvalConfig, build_submission_limits
    from adk_submission import ModelRegistry
    from adk_eval_core.tracing import SessionTrace
    from google.adk.models.lite_llm import LiteLlm
    from google.adk.agents.context_cache_config import ContextCacheConfig
    from google.adk.apps._configs import EventsCompactionConfig
    import litellm
    import yaml

    class OwnedManager(ContainerManager):
        def start(self):
            container = self.client.containers.run(
                self.config.image, command="sleep infinity", detach=True,
                network_mode="none", working_dir="/workspace",
                environment={"TEST_TMPDIR": "/tmp", "PIP_NO_INDEX": "1"},
                labels={LABEL: run_id},
            )
            cid = container.id
            with self._lock:
                self._active_containers.add(cid)
            with (run_dir / "container_ids.jsonl").open("a") as stream:
                stream.write(json.dumps({"id": cid, "time": time.time()}) + "\n")
            container.reload()
            security = {"id": cid, "privileged": container.attrs["HostConfig"]["Privileged"],
                        "network_mode": container.attrs["HostConfig"]["NetworkMode"],
                        "mounts": container.attrs.get("Mounts", []),
                        "binds": container.attrs["HostConfig"].get("Binds"),
                        "cap_add": container.attrs["HostConfig"].get("CapAdd")}
            write_json(run_dir / "container_security.json", security)
            if security["privileged"] or security["network_mode"] != "none" or security["mounts"] or security["binds"]:
                raise RuntimeError(f"Unsafe container configuration: {security}")
            return cid

    manager = OwnedManager(ContainerConfig(image=IMAGE, network_mode="none"))
    if diagnostic:
        try:
            cid = manager.start()
            extract_snapshot(manager, cid, SNAPSHOT)
            checks = {}
            for name, command, timeout in [
                ("output", "printf 'LINE1\\nLINE2\\nLINE3\\n'", 10),
                ("import", "cd /workspace && PYTHONPATH=/workspace PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1 python3 -s -c 'import git,gitdb,ddt; print(git.__file__); print(gitdb.__version__)'", 20),
                ("offline", "python3 -c 'import socket; s=socket.socket(); s.settimeout(1); s.connect((\"1.1.1.1\",443))'", 5),
                ("timeout", "sleep 10", 1),
            ]:
                result = manager.exec(cid, command, timeout=timeout)
                checks[name] = {"command": command, "stdout": result.stdout,
                                "stderr": result.stderr, "exit_code": result.exit_code}
            from swegemma.tools.execution import make_run_command
            from types import SimpleNamespace
            class Ctx:
                docker = manager
                container_id = cid
                harness = SimpleNamespace(command_timeout_seconds=10, max_stdout_chars=5000)
                budget = SimpleNamespace(time_minutes=None, tool_calls=None)
                tool_calls_used = 0
                def check_budget(self, **_kwargs):
                    return None
            checks["agent_output"] = make_run_command(Ctx())("printf 'LINE1\\nLINE2\\nLINE3\\n'")
            checks["passed"] = (checks["output"]["stdout"] == "LINE1\nLINE2\nLINE3\n"
                                and checks["agent_output"]["stdout"] == checks["output"]["stdout"]
                                and checks["import"]["exit_code"] == 0
                                and checks["offline"]["exit_code"] != 0
                                and checks["timeout"]["exit_code"] == 124)
            write_json(run_dir / "diagnostic.json", checks)
            return 0 if checks["passed"] else 1
        finally:
            manager.cleanup_all()

    while not (run_dir / "monitor.ready").exists():
        time.sleep(.1)
    task = Task(**task_input())
    agent_dir = run_dir / "agent_snapshot"
    shutil.copytree(ROOT / "data/sample_submission", agent_dir)
    sampling_path = agent_dir / "configs/sampling.yaml"
    original_sampling = yaml.safe_load(sampling_path.read_text())
    if "seed" in original_sampling:
        raise RuntimeError("Sample already specifies a seed")
    with sampling_path.open("a") as stream:
        stream.write(f"\nseed: {seed}\n")
    sample_eval = yaml.safe_load((agent_dir / "eval_config.yaml").read_text())["evaluation"]
    write_json(run_dir / "effective_settings.json", {
        "sample_evaluation": sample_eval,
        "local_pilot": {"max_time_minutes": 10, "max_tool_calls": 100,
                        "max_turns": 50, "timeout_seconds": 60,
                        "outer_deadline_seconds": 1200, "sampling_seed": seed},
        "sample_sampling": original_sampling,
        "effective_sampling": yaml.safe_load(sampling_path.read_text()),
        "agent_files_sha256": {str(p.relative_to(agent_dir)): sha256(p)
                               for p in agent_dir.rglob("*") if p.is_file()},
        "packages": {name: metadata.version(name) for name in (
            "swegemma", "adk-submission", "adk-eval-core", "google-adk",
            "vllm", "transformers", "torch", "litellm")},
    })
    litellm.drop_params = True
    litellm.telemetry = False
    models = ModelRegistry()
    models.register(MODEL_ALIAS, LiteLlm(model="openai/" + MODEL_ALIAS,
                   api_base=MODEL_URL, api_key="EMPTY", num_retries=5))
    for adapter in ("main_lora", "tool_lora"):
        models.register("adapter:" + adapter, LiteLlm(model="openai/" + adapter,
                        api_base=MODEL_URL, api_key="EMPTY", num_retries=5))
    limits, constraints = build_submission_limits()
    config = EvalConfig(
        tasks_path=run_dir / "safe_task_input.json", snapshots_dir=SNAPSHOT.parent,
        results_dir=run_dir, submission_dir=agent_dir, models=models,
        image=IMAGE, sandbox="docker", wheels_dir=WHEELS,
        graph_dir=str(run_dir / "no_graphs"), embeddings_dir=str(run_dir / "no_embeddings"),
        task_ids=[TASK_ID], concurrency=1, display_mode="quiet",
        timeout_seconds=60, max_time_minutes=10, max_tool_calls=100, max_turns=50,
        limits=limits, generation_constraints=constraints,
        context_cache_config=ContextCacheConfig(min_tokens=2048, ttl_seconds=1800, cache_intervals=10),
        events_compaction_config=EventsCompactionConfig(compaction_interval=15, overlap_size=2,
                                                        token_threshold=14336, event_retention_size=5),
    )

    original_git_exclude = agent_runner.setup_git_exclude
    def init_git(docker_manager, cid):
        command = ("cd /workspace && git init -q && git config user.name 'SWE pilot' "
                   "&& git config user.email 'swe-pilot@localhost' && test -z \"$(git remote)\"")
        response = docker_manager.exec(cid, command, timeout=20)
        if response.exit_code != 0:
            raise RuntimeError("Failed to initialize isolated source checkout: " + response.stderr)
        original_git_exclude(docker_manager, cid)
    agent_runner.setup_git_exclude = init_git
    agent_runner.install_test_dependencies = lambda *_args, **_kwargs: None
    agent_runner.setup_workspace_test_config = lambda *_args, **_kwargs: None
    agent_runner.setup_container_wheels = lambda *_args, **_kwargs: None

    class CheckpointTrace(SessionTrace):
        def _add(self, entry):
            super()._add(entry)
            self.save(run_dir / "trace.partial.tmp")
            (run_dir / "trace.partial.tmp").replace(run_dir / "trace.partial.json")
            entries = self.entries
            latest = entries[-1]
            write_json(run_dir / "progress.json", {
                "elapsed_seconds": self.duration,
                "events": len(entries),
                "tool_calls": sum(e.event_type == "tool_call" for e in entries),
                "llm_responses_with_usage": sum(bool(e.usage) for e in entries),
                "latest_action": (latest.tool_name or latest.event_type),
                "updated_at": time.time(),
            })
    agent_runner.SessionTrace = CheckpointTrace
    try:
        patch, error, trace = asyncio.run(agent_runner.run_agent_sandbox(
            manager, config, task, SNAPSHOT))
        trace.save(run_dir / "trace.json")
        (run_dir / "rollout.md").write_text(trace.to_markdown(
            max_thought_len=None, max_tool_args_len=None, max_tool_result_len=None,
            max_text_len=None, max_final_len=None, multiline_mode="code"))
        (run_dir / "agent.patch").write_text(patch)
        trace_data = trace.to_dict()
        metrics = trace_data.get("final_metrics", {})
        write_json(run_dir / "outcome.json", {
            "task_id": TASK_ID, "agent_error": error,
            "agent_timed_out": bool(error and "timeout" in error.lower()),
            "patch_status": "generated" if patch.strip() else "no_patch",
            "patch_bytes": len(patch.encode()),
            "token_usage": metrics,
            "tool_calls": trace.summarize().get("tool_calls"),
            "llm_responses_with_usage": sum(bool(e.usage) for e in trace.entries),
            "grading_status": "ungraded", "resolved": None,
            "grading_reason": "Pinned train row has no reliable FAIL_TO_PASS labels/evaluator metadata",
        })
        return 0
    finally:
        manager.cleanup_all()


def supervise_attempt(run_dir, run_id, seed, client):
    run_dir.mkdir(parents=True)
    write_json(run_dir / "safe_task_input.json", task_input())
    write_json(run_dir / "provenance.json", {
        "run_id": run_id, "source": "pinned Princeton NLP SWE-bench train split",
        "snapshot_sha256": sha256(SNAPSHOT), "image": IMAGE,
        "image_id": client.images.get(IMAGE).id,
        "dockerfile_sha256": sha256(HERE / "docker/gitpython-1028/Dockerfile"),
        "wheel_sha256": {p.name: sha256(p) for p in sorted(WHEELS.glob("*.whl"))},
        "gold_patch_visible": False, "test_patch_visible": False,
        "network": "none", "host_mounts": [], "cgroup_caps_enforced": False,
    })
    owned(client, run_id)
    monitor_started_at = time.time()
    command = [sys.executable, str(Path(__file__).resolve()), "--worker",
               "--run-dir", str(run_dir), "--run-id", run_id, "--seed", str(seed)]
    samples = []
    timed_out = False
    concern = None
    process = None
    last_report = 0
    deadline = time.monotonic() + 1200
    try:
        with (run_dir / "worker.log").open("w") as log:
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                       start_new_session=True)
        worker_started_at = time.time()
        (run_dir / "monitor.ready").write_text(str(monitor_started_at) + "\n")
        while process.poll() is None:
            if time.monotonic() >= deadline:
                timed_out = True
                break
            available = psutil.virtual_memory().available
            disk = shutil.disk_usage(HERE).free
            gpu = gpu_free_mib()
            if available < 16 * 1024**3 or disk < 5 * 1024**3 or gpu < 8000:
                concern = f"host pressure: RAM={available} disk={disk} GPU={gpu}MiB"
                break
            for container in owned(client, run_id):
                sample = {"time": time.time(), "container_id": container.id,
                          **container_rss(container)}
                samples.append(sample)
                if sample["rss_bytes"] is not None and sample["rss_bytes"] > 12 * 1024**3:
                    concern = f"observed container RSS above 12 GiB: {sample['rss_bytes']}"
                    break
            now = time.monotonic()
            if now - last_report >= 30:
                progress_path = run_dir / "progress.json"
                progress = json.loads(progress_path.read_text()) if progress_path.exists() else {}
                print(f"{run_dir.name}: elapsed={int(1200-(deadline-now))}s "
                      f"tools={progress.get('tool_calls', 0)} "
                      f"LLM={progress.get('llm_responses_with_usage', 0)} "
                      f"latest={progress.get('latest_action', 'setup')}",
                      flush=True)
                last_report = now
            if concern:
                break
            time.sleep(2)
    except KeyboardInterrupt:
        concern = "interrupted"
    finally:
        if process and process.poll() is None:
            # Preserve the working tree before an outer deadline or resource stop.
            for container in owned(client, run_id):
                try:
                    capture = container.exec_run(
                        ["/bin/bash", "-c", "cd /workspace && git add -N . && "
                         "git diff --binary _swegemma_baseline"],
                        stdout=True, stderr=True, demux=True)
                    stdout, stderr = capture.output
                    (run_dir / "outer_stop_worktree.patch").write_bytes(stdout or b"")
                    (run_dir / "outer_stop_capture.stderr").write_bytes(stderr or b"")
                except Exception as exc:
                    (run_dir / "outer_stop_capture.error").write_text(str(exc))
        if process and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        removed = cleanup(client, run_id)
        remaining = [c.id for c in owned(client, run_id)]
        write_json(run_dir / "monitor.json", {
            "monitor_started_at": monitor_started_at,
            "worker_started_at": worker_started_at if process else None,
            "samples": samples, "peak_observed_rss_bytes": max(
                (s["rss_bytes"] or 0 for s in samples), default=0),
            "outer_timed_out": timed_out, "resource_concern": concern,
            "worker_exit_code": process.returncode if process else None,
            "cleanup_ids": removed, "remaining_owned_ids": remaining,
            "cleanup_ok": not remaining,
        })
    return not timed_out and concern is None and process.returncode == 0 and not remaining


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--diagnostic", action="store_true")
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--run-id")
    parser.add_argument("--seed", type=int)
    args = parser.parse_args()
    if args.worker:
        return worker(args.run_dir, args.run_id, args.seed, args.diagnostic)
    batch = HERE / "trajectories" / f"pilot-{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6]}"
    batch.mkdir(parents=True)
    client = docker.from_env(timeout=10)
    if shutil.disk_usage(HERE).free < 8 * 1024**3:
        raise RuntimeError("Less than 8 GiB disk free before attempts")
    if psutil.virtual_memory().available < 16 * 1024**3:
        raise RuntimeError("Insufficient host available RAM")
    with socket.socket() as check:
        if check.connect_ex(("127.0.0.1", 8001)) == 0:
            raise RuntimeError("Port 8001 already occupied; refusing to take over server")
    gpu_before = gpu_free_mib()
    if gpu_before < 62000:
        raise RuntimeError(f"Insufficient GPU memory: {gpu_before} MiB")
    write_json(batch / "batch_manifest.json", {
        "task_id": TASK_ID, "attempts_planned": 2, "sequential": True,
        "seeds": [1028, 21028], "gpu_free_mib_before_server": gpu_before,
        "disk_free_bytes_before_server": shutil.disk_usage(HERE).free,
        "image_id": client.images.get(IMAGE).id,
    })
    server = None
    created_at = None
    attempts = []
    try:
        env = os.environ.copy()
        env["BASELINE_GPU_FRACTION"] = "0.60"
        env["PATH"] = str(Path(sys.executable).parent) + os.pathsep + env.get("PATH", "")
        with (batch / "vllm.log").open("w") as log:
            server = subprocess.Popen(["bash", str(KIT / "serve.sh")], cwd=KIT,
                                      env=env, stdout=log, stderr=subprocess.STDOUT,
                                      start_new_session=True)
        created_at = psutil.Process(server.pid).create_time()
        write_json(batch / "server_record.json", {
            "pid": server.pid, "create_time": created_at,
            "process_group": os.getpgid(server.pid),
            "serve_script_sha256": sha256(KIT / "serve.sh"),
            "gpu_memory_fraction": 0.60, "max_num_seqs": 1})
        startup_deadline = time.monotonic() + 600
        while True:
            if server.poll() is not None:
                raise RuntimeError(f"vLLM exited during startup: {server.returncode}")
            if time.monotonic() >= startup_deadline:
                raise TimeoutError("vLLM startup exceeded 600 seconds")
            if gpu_free_mib() < 8000:
                raise RuntimeError("GPU free memory fell below 8 GiB during server startup")
            try:
                with urllib.request.urlopen(MODEL_URL + "/models", timeout=2) as response:
                    models = json.load(response)
                ids = {entry["id"] for entry in models["data"]}
                if {MODEL_ALIAS, "main_lora", "tool_lora"} <= ids:
                    write_json(batch / "served_models.json", models)
                    break
            except Exception:
                time.sleep(2)
        with (batch / "model_probe.log").open("w") as log:
            subprocess.run([sys.executable, str(KIT / "probe_models.py"),
                            "--output", str(batch / "model_probe.json")], cwd=KIT,
                           stdout=log, stderr=subprocess.STDOUT, timeout=390, check=True)
        for index, seed in enumerate((1028, 21028), 1):
            run_id = f"swe-gitpython-1028-{index}-{uuid.uuid4().hex}"
            run_dir = batch / f"attempt-{index}"
            print(f"Starting attempt {index}/2, seed={seed}", flush=True)
            ok = supervise_attempt(run_dir, run_id, seed, client)
            outcome_path = run_dir / "outcome.json"
            outcome = json.loads(outcome_path.read_text()) if outcome_path.exists() else None
            attempts.append({"attempt": index, "run_id": run_id, "run_dir": str(run_dir),
                             "completed": ok, "outcome": outcome})
            write_json(batch / "summary.json", {"attempts": attempts})
            if not ok:
                print(f"Stopping after attempt {index}: infrastructure or cleanup failure", flush=True)
                break
    finally:
        stopped = stop_server(server, created_at) if server else None
        write_json(batch / "summary.json", {"attempts": attempts, "server_cleanup": stopped,
                                             "batch_dir": str(batch)})
        print(f"Results: {batch}", flush=True)
    return 0 if len(attempts) == 2 and all(a["completed"] for a in attempts) else 1


if __name__ == "__main__":
    raise SystemExit(main())
