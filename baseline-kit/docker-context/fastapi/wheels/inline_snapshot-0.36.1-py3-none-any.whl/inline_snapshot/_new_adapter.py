from __future__ import annotations

import ast
import warnings
from collections import defaultdict
from dataclasses import dataclass
from typing import Any
from typing import Generator
from typing import Sequence

from inline_snapshot._adapter_context import AdapterContext
from inline_snapshot._align import add_x
from inline_snapshot._align import align
from inline_snapshot._change import CallArg
from inline_snapshot._change import ChangeBase
from inline_snapshot._change import Delete
from inline_snapshot._change import DictInsert
from inline_snapshot._change import ListInsert
from inline_snapshot._change import Replace
from inline_snapshot._compare_context import compare_context
from inline_snapshot._customize._builder import Builder
from inline_snapshot._customize._custom import Custom
from inline_snapshot._customize._custom_call import CustomCall
from inline_snapshot._customize._custom_call import CustomDefault
from inline_snapshot._customize._custom_code import CustomCode
from inline_snapshot._customize._custom_dict import CustomDict
from inline_snapshot._customize._custom_sequence import CustomList
from inline_snapshot._customize._custom_sequence import CustomSet
from inline_snapshot._customize._custom_sequence import CustomTuple
from inline_snapshot._customize._custom_undefined import CustomUndefined
from inline_snapshot._customize._custom_unmanaged import CustomUnmanaged
from inline_snapshot._customize._uncustomized import Uncustomized
from inline_snapshot._exceptions import UsageError
from inline_snapshot._generator_utils import make_gen_map
from inline_snapshot._generator_utils import only_value
from inline_snapshot._generator_utils import split_gen
from inline_snapshot.syntax_warnings import InlineSnapshotInfo
from inline_snapshot.syntax_warnings import InlineSnapshotSyntaxWarning


def warn_star_expression(node, context):
    if isinstance(node, ast.Call):
        for pos_arg in node.args:
            if isinstance(pos_arg, ast.Starred):
                warnings.warn_explicit(
                    "star-expressions are not supported inside snapshots",
                    filename=context.file._source.filename,
                    lineno=pos_arg.lineno,
                    category=InlineSnapshotSyntaxWarning,
                )
                return True

        # keyword arguments
        for kw in node.keywords:
            if kw.arg is None:
                warnings.warn_explicit(
                    "star-expressions are not supported inside snapshots",
                    filename=context.file._source.filename,
                    lineno=kw.value.lineno,
                    category=InlineSnapshotSyntaxWarning,
                )
                return True

    if isinstance(node, (ast.Tuple, ast.List)):

        for e in node.elts:
            if isinstance(e, ast.Starred):
                warnings.warn_explicit(
                    "star-expressions are not supported inside snapshots",
                    filename=context.file.filename,
                    lineno=e.lineno,
                    category=InlineSnapshotSyntaxWarning,
                )
                return True
    if isinstance(node, ast.Dict):

        for key1, value in zip(node.keys, node.values):
            if key1 is None:
                warnings.warn_explicit(
                    "star-expressions are not supported inside snapshots",
                    filename=context.file._source.filename,
                    lineno=value.lineno,
                    category=InlineSnapshotSyntaxWarning,
                )
                return True

    return False


def reeval(old_value: Custom, value: Custom) -> Custom:
    function_name = f"reeval_{type(old_value).__name__}"
    result = globals()[function_name](old_value, value)
    assert isinstance(result, Custom)

    return result


def reeval_CustomList(old_value: CustomList, value: CustomList):
    assert len(old_value.value) == len(value.value)
    return CustomList([reeval(a, b) for a, b in zip(old_value.value, value.value)])


def reeval_CustomTuple(old_value: CustomTuple, value: CustomTuple):
    assert len(old_value.value) == len(value.value)
    return CustomTuple([reeval(a, b) for a, b in zip(old_value.value, value.value)])


def reeval_CustomSet(old_value: CustomSet, value: CustomSet):
    if old_value._eval() != value._eval():
        raise UsageError(
            "snapshot value should not change. Use Is(...) for dynamic snapshot parts."
        )
    return value


def reeval_CustomUnmanaged(old_value: CustomUnmanaged, value: CustomUnmanaged):
    old_value.value = value.value
    return old_value


def reeval_CustomUndefined(old_value, value):
    return value


def reeval_CustomCode(old_value: CustomCode, value: CustomCode):

    if not old_value._eval() == value._eval():
        raise UsageError(
            "snapshot value should not change. Use Is(...) for dynamic snapshot parts."
        )

    return value


def reeval_CustomCall(old_value: CustomCall, value: CustomCall):
    return CustomCall(
        reeval(old_value.function, value.function),
        [reeval(a, b) for a, b in zip(old_value.args, value.args)],
        {k: reeval(old_value.kwargs[k], value.kwargs[k]) for k in old_value.kwargs},
    )


def reeval_CustomDict(old_value, value):
    assert len(old_value.value) == len(value.value)
    return CustomDict(
        {
            reeval(k1, k2): reeval(v1, v2)
            for (k1, v1), (k2, v2) in zip(old_value.value.items(), value.value.items())
        }
    )


@dataclass(frozen=True)
class OriginalValue:
    value: Any

    @staticmethod
    def from_input(value: Any) -> OriginalValue | None:
        if isinstance(value, Uncustomized):
            return OriginalValue(value._value)
        if isinstance(value, Custom):
            return None
        return OriginalValue(value)


@dataclass(frozen=True)
class Comparison:
    # None means an explicit builder node with no known original value.
    # OriginalValue(None) represents the actual runtime value None.
    original: OriginalValue | None = None
    flag: str = "fix"


class NewAdapter:

    def __init__(
        self, context: AdapterContext, *, comparison: Comparison = Comparison()
    ):
        assert context.expr.node is not None
        self.context = context
        self._comparison = comparison

    def get_builder(self, **args):
        return Builder(_snapshot_context=self.context, **args)

    def customize(self, value, snapshot_value: Custom):
        return self.get_builder(_build_new_value=True)._customize(value, snapshot_value)

    def customize_all(self, value):
        return self.get_builder(_build_new_value=True)._customize_all(value)

    def _get_change_flag(
        self, old_value: Custom, original: OriginalValue | None
    ) -> str:
        if isinstance(old_value, CustomUndefined):
            return "create"
        if original is None:
            # Explicit builder nodes inherit the category from the closest
            # ancestor with a known original runtime value. A matcher's value
            # cannot substitute for that original value.
            return self._comparison.flag
        return "update" if old_value._eval() == original.value else "fix"

    def compare(
        self, old_value: Custom, old_node, new_value: Any
    ) -> Generator[ChangeBase, None, Custom]:

        original = OriginalValue.from_input(new_value)
        if original is not None:
            new_value = self.customize(original.value, old_value)

            # Pydantic generic classes can be represented by their origin.
            # Match the same equivalence accepted by the builder's validation.
            if hasattr(original.value, "__pydantic_generic_metadata__"):
                evaluated = new_value._eval()
                if original.value.__pydantic_generic_metadata__["origin"] == evaluated:
                    original = OriginalValue(evaluated)

        flag = self._get_change_flag(old_value, original)
        if isinstance(old_value, CustomUndefined):
            new_value = self.customize_all(new_value)

        if isinstance(old_value, CustomUnmanaged):
            return old_value

        if isinstance(new_value, CustomUnmanaged):
            raise UsageError("unmanaged values cannot be compared with snapshots")

        adapter = NewAdapter(self.context, comparison=Comparison(original, flag))
        if type(old_value) is type(new_value) and isinstance(
            old_node, new_value.node_type
        ):
            function_name = f"compare_{type(old_value).__name__}"
            result_gen = getattr(adapter, function_name)(old_value, old_node, new_value)
        else:
            result_gen = adapter.compare_CustomCode(old_value, old_node, new_value)

        if flag == "update":

            @make_gen_map
            def fix_to_update(change):
                if change.flag == "fix":
                    change.flag = "update"
                return change

            result_gen = fix_to_update(result_gen)

        result = yield from result_gen
        return result

    def compare_CustomCode(
        self, old_value: Custom, old_node: ast.expr, new_value: Custom
    ) -> Generator[ChangeBase, None, Custom]:

        assert isinstance(old_value, Custom)
        new_value = self.customize_all(new_value)
        assert isinstance(new_value, Custom)
        assert isinstance(old_node, ast.expr), old_node

        new_code, new_changes = split_gen(new_value._code_repr(self.context))

        if (
            isinstance(old_node, ast.JoinedStr)
            and isinstance(new_value, CustomCode)
            and isinstance(new_value.value, str)
        ):
            if not old_value._eval() == new_value._eval():

                value = only_value(new_value._code_repr(self.context))
                warnings.warn_explicit(
                    f"inline-snapshot will be able to fix f-strings in the future.\nThe current string value is:\n   {value}",
                    filename=self.context.file._source.filename,
                    lineno=old_node.lineno,
                    category=InlineSnapshotInfo,
                )
            return old_value

        if self._comparison.flag == "update" or self._comparison.original is None:
            if not self.context.file.code_changed(old_node, new_code):
                return old_value

        flag = self._comparison.flag
        for change in new_changes:
            change.flag = flag
            yield change

        yield Replace(
            node=old_node,
            file=self.context.file,
            new_code=new_code,
            flag=flag,
        )

        return new_value

    def compare_CustomList(
        self, old_value: CustomList, old_node: ast.AST, new_value: CustomList
    ) -> Generator[ChangeBase, None, CustomList]:

        assert isinstance(
            old_node, ast.List if isinstance(old_value._eval(), list) else ast.Tuple
        )
        assert isinstance(old_node, (ast.List, ast.Tuple))

        with compare_context():
            diff = add_x(align(old_value.value, new_value.value))
        old = zip(
            old_value.value,
            old_node.elts,
        )
        new = iter(new_value.value)
        old_position = 0
        to_insert = defaultdict(list)
        result = []
        for c in diff:
            if c in "mx":
                old_value_element, old_node_element = next(old)
                new_value_element = next(new)
                v = yield from self.compare(
                    old_value_element,
                    old_node_element,
                    new_value_element,
                )
                result.append(v)
                old_position += 1
            elif c == "i":
                new_value_element = next(new)
                new_value_element = self.customize_all(new_value_element)
                new_code = yield from new_value_element._code_repr(self.context)
                result.append(new_value_element)
                to_insert[old_position].append(new_code)
            elif c == "d":
                old_value_element, old_node_element = next(old)
                yield Delete(
                    self._comparison.flag,
                    self.context.file,
                    old_node_element,
                )
                old_position += 1
            else:
                assert False

        for position, code_values in to_insert.items():
            yield ListInsert(
                self._comparison.flag,
                self.context.file,
                old_node,
                position,
                code_values,
            )

        return type(new_value)(result)

    def compare_CustomTuple(
        self, old_value: CustomTuple, old_node: ast.AST, new_value: CustomTuple
    ) -> Generator[ChangeBase, None, CustomTuple]:
        """Compare tuples positionally: match elements at the same index,
        delete surplus old elements, insert extra new elements."""

        assert isinstance(old_node, ast.Tuple)

        old_elts = old_value.value
        new_elts = new_value.value
        old_nodes = old_node.elts

        common = min(len(old_elts), len(new_elts))
        result = []

        # compare paired elements
        for old_elem, old_node_elem, new_elem in zip(old_elts, old_nodes, new_elts):
            v = yield from self.compare(
                old_elem,
                old_node_elem,
                new_elem,
            )
            result.append(v)

        # delete surplus old elements
        for old_node_elem in old_nodes[common:]:
            yield Delete(self._comparison.flag, self.context.file, old_node_elem)

        # insert extra new elements
        if len(new_elts) > common:
            to_insert = []
            for new_elem in new_elts[common:]:
                new_elem = self.customize_all(new_elem)
                new_code = yield from new_elem._code_repr(self.context)
                to_insert.append(new_code)
                result.append(new_elem)

            yield ListInsert(
                self._comparison.flag,
                self.context.file,
                old_node,
                common,
                to_insert,
            )

        return CustomTuple(result)

    def compare_CustomSet(
        self, old_value: CustomSet, old_node: ast.Set, new_value: CustomSet
    ) -> Generator[ChangeBase, None, Custom]:
        assert isinstance(old_node, ast.Set)

        # A set's iteration order cannot be associated with the source order of
        # its AST elements. Compare it atomically instead of attempting
        # positional element updates.
        if self._comparison.original is not None and self._comparison.flag == "update":
            return old_value

        # Sets are replaced atomically, so their elements do not pass through
        # compare() individually.  Resolve the lazy nodes before rendering the
        # replacement.
        return (yield from self.compare_CustomCode(old_value, old_node, new_value))

    def compare_CustomDict(
        self, old_value: CustomDict, old_node: ast.Dict, new_value: CustomDict
    ) -> Generator[ChangeBase, None, Custom]:
        assert isinstance(old_value, CustomDict)
        assert isinstance(new_value, CustomDict)

        for value2, node in zip(old_value.value.keys(), old_node.keys):
            assert node is not None
            try:
                # this is just a sanity check, dicts should be ordered
                node_value = ast.literal_eval(node)
            except Exception:
                continue
            assert node_value == value2._eval()

        old_keys = list(old_value.value.keys())
        old_entries = {
            old_key: (old_key, key_node, value_node)
            for old_key, key_node, value_node in zip(
                old_keys, old_node.keys, old_node.values
            )
        }

        result = {}
        for key2, (_, _, value_node) in old_entries.items():
            if key2 not in new_value.value:
                # delete entries
                yield Delete(self._comparison.flag, self.context.file, value_node)

        to_insert = []
        insert_pos = 0
        for key, new_value_element in new_value.value.items():
            if key not in old_value.value:
                # add new values
                result_key = self.customize_all(key)
                new_value_element = self.customize_all(new_value_element)
                to_insert.append((result_key, new_value_element))
                result[result_key] = new_value_element
            else:
                old_key, key_node, value_node = old_entries[key]
                assert key_node is not None
                result_key = yield from self.compare(old_key, key_node, key)
                result[result_key] = yield from self.compare(
                    old_value.value[key], value_node, new_value_element
                )

                if to_insert:
                    new_code = []
                    for k, v in to_insert:
                        new_code_key = yield from k._code_repr(self.context)
                        new_code_value = yield from v._code_repr(self.context)
                        new_code.append((new_code_key, new_code_value))

                    yield DictInsert(
                        self._comparison.flag,
                        self.context.file,
                        old_node,
                        insert_pos,
                        new_code,
                    )
                    to_insert = []

                insert_pos += 1

        if to_insert:
            new_code = []
            for k, v in to_insert:
                new_code_key = yield from k._code_repr(self.context)
                new_code_value = yield from v._code_repr(self.context)
                new_code.append(
                    (
                        new_code_key,
                        new_code_value,
                    )
                )

            yield DictInsert(
                self._comparison.flag,
                self.context.file,
                old_node,
                len(old_value.value),
                new_code,
            )

        return CustomDict(value=result)

    def compare_CustomCall(
        self, old_value: CustomCall, old_node: ast.Call, new_value: CustomCall
    ) -> Generator[ChangeBase, None, Custom]:

        new_args = new_value.args
        new_kwargs = new_value.kwargs

        # positional arguments

        result_args = []

        flag = self._comparison.flag

        old_node_args: Sequence[ast.expr | None] = old_node.args

        old_args_len = len(old_node.args)

        for i, (new_value_element, node) in list(
            enumerate(zip(new_args, old_node_args))
        )[:old_args_len]:
            old_value_element = old_value.argument(i)
            result = yield from (
                self.compare(old_value_element, node, new_value_element)
            )
            result_args.append(result)

        if old_args_len > len(new_args):
            for arg_pos, node in list(enumerate(old_node.args))[len(new_args) :]:
                yield Delete(
                    flag,
                    self.context.file,
                    node,
                )

        if old_args_len < len(new_args):
            for insert_pos, insert_value in list(enumerate(new_args))[old_args_len:]:
                insert_value = self.customize_all(insert_value)
                new_code = yield from insert_value._code_repr(self.context)
                yield CallArg(
                    flag=flag,
                    file=self.context.file,
                    node=old_node,
                    arg_pos=insert_pos,
                    arg_name=None,
                    new_code=new_code,
                )
                result_args.append(insert_value)

        # keyword arguments
        result_kwargs = {}
        old_keywords = {
            kw.arg: kw.value for kw in old_node.keywords if kw.arg is not None
        }

        for kw_arg, kw_value in old_keywords.items():
            missing = kw_arg not in new_kwargs
            if missing or isinstance(new_kwargs[kw_arg], CustomDefault):
                # delete entries
                yield Delete(
                    (
                        flag
                        if missing
                        else self._get_change_flag(
                            old_value.argument(kw_arg),
                            OriginalValue.from_input(new_value.argument(kw_arg)),
                        )
                    ),
                    self.context.file,
                    kw_value,
                )

        to_insert = []
        insert_pos = len(old_value.args)
        for key, new_value_element in new_kwargs.items():
            if isinstance(new_value_element, CustomDefault):
                continue
            if key not in old_keywords:
                # add new values
                new_value_element = self.customize_all(new_value_element)
                to_insert.append((key, new_value_element))
                result_kwargs[key] = new_value_element
            else:
                node = old_keywords[key]

                # check values with same keys
                old_value_element = old_value.argument(key)
                result_kwargs[key] = yield from (
                    self.compare(old_value_element, node, new_value_element)
                )

                if to_insert:
                    for insert_key, value in to_insert:
                        new_code = yield from value._code_repr(self.context)
                        yield CallArg(
                            flag=flag,
                            file=self.context.file,
                            node=old_node,
                            arg_pos=insert_pos,
                            arg_name=insert_key,
                            new_code=new_code,
                        )
                    to_insert = []

                insert_pos += 1

        if to_insert:

            for key, value in to_insert:
                new_code = yield from value._code_repr(self.context)

                yield CallArg(
                    flag=flag,
                    file=self.context.file,
                    node=old_node,
                    arg_pos=None,
                    arg_name=key,
                    new_code=new_code,
                )

        return CustomCall(
            (
                yield from (
                    self.compare(
                        old_value.function,
                        old_node.func,
                        new_value.function,
                    )
                )
            ),
            result_args,
            result_kwargs,
        )
